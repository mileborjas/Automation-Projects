import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://automationexercise.com/")
selenium.click("link=� Products")
selenium.click("id=search_product")
String productName = "TSHIRT"
selenium.type("id=search_product", (productName).toString())
selenium.click("id=submit_search")
for (int second = 0;; second++){
    if (second >= 60) fail("timeout")
    try{
        
        if (selenium.isElementPresent("link=View Product")) break
    } catch (Exception e){
    
    }
    Thread.sleep(1000)
  }
selenium.click("link=View Product")
selenium.click("xpath=//button[@type='button']")
selenium.click("xpath=//div[@id='cartModal']/div/div/div[3]/button")
softAssertion.assertEquals("Your product has been added to cart.", selenium.getText("//*[@id=\"cartModal\"]/div/div/div[2]/p[1]"))
String counter = "0"
while (counter < 3) {
selenium.click("xpath=//button[@type='button']")
selenium.click("xpath=//div[@id='cartModal']/div/div/div[3]/button")
counter = WebUI.executeJavaScript("return Number(" + counter + ") + 1", null)
/* Katalon Studio does not support: gotoIf */
softAssertion.assertEquals("Your product has been added to cart.", selenium.getText("//*[@id=\"cartModal\"]/div/div/div[2]/p[1]"))
