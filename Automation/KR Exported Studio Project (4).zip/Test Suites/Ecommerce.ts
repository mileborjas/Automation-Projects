<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Ecommerce</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4b683f6d-0f6d-44f0-b49d-c52b4864e813</testSuiteGuid>
   <testCaseLink>
      <guid>a248c52f-0e88-4cc3-a14f-3606791c7627</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Ecommerce/TC01_Ecommerce_Purchase_Loop</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e7cb6ee9-72f6-462b-9d41-e1f6e04c992f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Ecommerce/TC02_Invalid_Login</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>c0d001ed-f38f-442f-8ccf-fccc3c45514d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Ecommerce/TC03_Search_Product_Validation</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    