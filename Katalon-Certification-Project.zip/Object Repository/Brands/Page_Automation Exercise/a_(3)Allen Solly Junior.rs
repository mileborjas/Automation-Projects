<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(3)Allen Solly Junior</name>
   <tag></tag>
   <elementGuidId>4932a453-e103-49ec-b5fa-4b55e6cc9acf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-pills.nav-stacked > li:nth-of-type(6) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(4)'])[1]/following::a[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>823f64b5-5e85-41d0-9368-7ff8c66de3ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/brand_products/Allen Solly Junior</value>
      <webElementGuid>ef75d40b-6bfc-4a64-bc40-736e33421293</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (3)Allen Solly Junior</value>
      <webElementGuid>7939bfee-6b8c-41e6-8c8d-565b18843bfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[2]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-3&quot;]/div[@class=&quot;left-sidebar&quot;]/div[@class=&quot;brands_products&quot;]/div[@class=&quot;brands-name&quot;]/ul[@class=&quot;nav nav-pills nav-stacked&quot;]/li[6]/a[1]</value>
      <webElementGuid>2ab40a2a-9af2-432f-8546-e8ca3fdece62</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(4)'])[1]/following::a[1]</value>
      <webElementGuid>abd66a62-9beb-4bdc-bbae-7601678a291e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Allen Solly Junior']/parent::*</value>
      <webElementGuid>db6ec61d-64f5-4cd6-96b8-b424ca59da4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/brand_products/Allen Solly Junior')]</value>
      <webElementGuid>285a6381-d2fd-4ac7-8885-3374b6d83491</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div[2]/div/ul/li[6]/a</value>
      <webElementGuid>c3cc19b7-acce-46f7-b0a9-d744345e6829</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/brand_products/Allen Solly Junior' and (text() = ' (3)Allen Solly Junior' or . = ' (3)Allen Solly Junior')]</value>
      <webElementGuid>acb3fab5-6ba8-4372-9919-0d4f61cfe060</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
