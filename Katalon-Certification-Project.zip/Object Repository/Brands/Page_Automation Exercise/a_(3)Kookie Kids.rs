<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(3)Kookie Kids</name>
   <tag></tag>
   <elementGuidId>57993bd8-efa8-4e35-9915-7d21822ccea3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-pills.nav-stacked > li:nth-of-type(7) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(3)'])[2]/following::a[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c1bd9135-800a-4be5-86eb-364755bf5689</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/brand_products/Kookie Kids</value>
      <webElementGuid>ab8da422-fe65-4b64-a51b-65c870378c4a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (3)Kookie Kids</value>
      <webElementGuid>95f1abb0-1bab-45d7-8306-71b4a19b71ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[2]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-3&quot;]/div[@class=&quot;left-sidebar&quot;]/div[@class=&quot;brands_products&quot;]/div[@class=&quot;brands-name&quot;]/ul[@class=&quot;nav nav-pills nav-stacked&quot;]/li[7]/a[1]</value>
      <webElementGuid>c402e2d0-b893-4913-a9c3-d4ce2db7ec9f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(3)'])[2]/following::a[1]</value>
      <webElementGuid>7a96e2b1-7b91-4194-ba5c-68ba75f8bcd6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kookie Kids']/parent::*</value>
      <webElementGuid>70c63efe-a417-4b9d-9dfb-8a42ab623b5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/brand_products/Kookie Kids')]</value>
      <webElementGuid>51b92fcb-cb5e-46a2-8110-655ac4e4f5ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div[2]/div/ul/li[7]/a</value>
      <webElementGuid>dccb7cb6-70e5-486d-9fa7-8621b945ea98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/brand_products/Kookie Kids' and (text() = ' (3)Kookie Kids' or . = ' (3)Kookie Kids')]</value>
      <webElementGuid>53e1a193-c64a-4fc1-b9b8-a48b3ad47e65</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
