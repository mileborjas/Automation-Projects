<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_(3)Mast  Harbour</name>
   <tag></tag>
   <elementGuidId>01e29911-25f4-4680-bca3-018cc7fbcbd0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-pills.nav-stacked > li:nth-of-type(4) > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[2]/following::a[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>96d51f23-1aad-479b-9130-64848f18171e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/brand_products/Mast &amp; Harbour</value>
      <webElementGuid>c7c69c7c-ee84-4ff0-8d21-a81167bfe3d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (3)Mast &amp; Harbour</value>
      <webElementGuid>6034b8e5-a371-4d38-8e52-f72dc38f863c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[2]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-3&quot;]/div[@class=&quot;left-sidebar&quot;]/div[@class=&quot;brands_products&quot;]/div[@class=&quot;brands-name&quot;]/ul[@class=&quot;nav nav-pills nav-stacked&quot;]/li[4]/a[1]</value>
      <webElementGuid>fdc2933a-fdf4-43cd-9baa-4991ad4e7bd3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[2]/following::a[1]</value>
      <webElementGuid>f619639e-01f2-4ae1-a750-1d90cd4b60db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mast &amp; Harbour']/parent::*</value>
      <webElementGuid>eb3d05a2-74a6-4523-8c1c-b2046ee6cfa0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/brand_products/Mast &amp; Harbour')]</value>
      <webElementGuid>814da39d-0a82-4f27-81c7-3763204f49ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div[2]/div/ul/li[4]/a</value>
      <webElementGuid>03e71a0e-e785-44fb-9043-24f5bdda7d2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/brand_products/Mast &amp; Harbour' and (text() = ' (3)Mast &amp; Harbour' or . = ' (3)Mast &amp; Harbour')]</value>
      <webElementGuid>372b9e25-0b14-4b90-b528-569178c7c254</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
