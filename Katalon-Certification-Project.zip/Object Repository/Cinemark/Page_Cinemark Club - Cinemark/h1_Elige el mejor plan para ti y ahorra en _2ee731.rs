<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Elige el mejor plan para ti y ahorra en _2ee731</name>
   <tag></tag>
   <elementGuidId>ba1b13bf-0c32-415f-86d2-f5db01f10d4b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Elegir Película'])[3]/following::h1[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.MuiTypography-root.MuiTypography-h1.MuiTypography-alignCenter.mui-85hanf</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>4908f605-32ee-44c5-b4b7-034c48580709</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiTypography-root MuiTypography-h1 MuiTypography-alignCenter mui-85hanf</value>
      <webElementGuid>8c4e222a-6b2c-4012-bbbe-63fa1cbd08a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Elige el mejor plan para ti y ahorra en tus visitas</value>
      <webElementGuid>a64df96a-b034-4b2b-bcaa-d6b20c60c1c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg mui-bjhooc&quot;]/div[@class=&quot;MuiBox-root mui-1umlh4c&quot;]/h1[@class=&quot;MuiTypography-root MuiTypography-h1 MuiTypography-alignCenter mui-85hanf&quot;]</value>
      <webElementGuid>809a4a20-10f8-43ba-a0c7-619af9c10312</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elegir Película'])[3]/following::h1[1]</value>
      <webElementGuid>fb6be420-5db0-4170-a582-b9a46515d116</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cinemark Alto Las Condes'])[3]/following::h1[1]</value>
      <webElementGuid>7bebd6b4-9846-4b52-854c-253933efa313</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sin costo mensual'])[1]/preceding::h1[1]</value>
      <webElementGuid>bee81e90-dc4a-4978-ba8f-687a563a4653</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Descuento en entradas'])[1]/preceding::h1[3]</value>
      <webElementGuid>f4361bdd-3c0d-4de3-a881-c236ac51893a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Elige el mejor plan para ti y ahorra en tus visitas']/parent::*</value>
      <webElementGuid>50e34993-9da7-4301-a3f0-e0d8220c614f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>522d21fc-8c16-407f-bee9-3826f68f89f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Elige el mejor plan para ti y ahorra en tus visitas' or . = 'Elige el mejor plan para ti y ahorra en tus visitas')]</value>
      <webElementGuid>42f9fe08-a5f5-4e0a-bffa-144c3a04d579</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
