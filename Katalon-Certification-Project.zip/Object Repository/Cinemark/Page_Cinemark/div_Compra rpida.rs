<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Compra rpida</name>
   <tag></tag>
   <elementGuidId>27495eb6-0d2b-4669-bce5-c874efa8328a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Política y Uso de Cookies'])[2]/following::div[8]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiBox-root.mui-axw7ok</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>cf31dafc-678d-4a64-9cfe-792953335272</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root mui-axw7ok</value>
      <webElementGuid>d0084be9-c24b-4af4-a659-a1d466836b98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Compra rápida</value>
      <webElementGuid>9ef5d8ad-6e55-4cb0-b504-56537d0fdc93</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;MuiBox-root mui-nznmpf&quot;]/button[@class=&quot;MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-colorPrimary MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButton-colorPrimary mui-181z1x4&quot;]/div[@class=&quot;MuiBox-root mui-axw7ok&quot;]</value>
      <webElementGuid>e1276595-1bd4-44a0-bfa5-03b472de7292</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Política y Uso de Cookies'])[2]/following::div[8]</value>
      <webElementGuid>d4482d4e-a3f3-4f4b-86ad-b0ac4c4c665a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Política de Privacidad'])[2]/following::div[9]</value>
      <webElementGuid>a326b750-5ea1-40b3-9c62-9cbda93dff47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Compra rápida']/parent::*</value>
      <webElementGuid>0b946447-9102-488a-83b0-2bd362a1a02a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/div</value>
      <webElementGuid>35f06f49-78aa-4249-be2c-59dbac9d0518</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Compra rápida' or . = 'Compra rápida')]</value>
      <webElementGuid>b4038cfe-3776-442b-b890-fefd050874b5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
