<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_CDIGOS CINEMARKCOMPRA AHORA, DISFRUTA CUANDO QUIERAS</name>
   <tag></tag>
   <elementGuidId>7edf0157-6754-4179-80ce-8b204c3985a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Elegir Película'])[3]/following::h1[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.MuiTypography-root.MuiTypography-h1.mui-pale82</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>7cb00cb0-6435-441c-8207-6f0e9cf66297</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiTypography-root MuiTypography-h1 mui-pale82</value>
      <webElementGuid>8ad137e7-0990-4bc7-9d50-3aeb727a0e2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CÓDIGOS CINEMARK: ¡COMPRA AHORA, DISFRUTA CUANDO QUIERAS!</value>
      <webElementGuid>a96ecd7e-4d28-4819-b75f-d16b2201ea28</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg mui-bjhooc&quot;]/h1[@class=&quot;MuiTypography-root MuiTypography-h1 mui-pale82&quot;]</value>
      <webElementGuid>0c9b6aa7-60ee-4e58-8440-31388c66a2c1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elegir Película'])[3]/following::h1[1]</value>
      <webElementGuid>75ee2087-5e97-4a93-b9a2-10f1f46ab771</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cinemark Alto Las Condes'])[3]/following::h1[1]</value>
      <webElementGuid>8ca5e3f6-1f94-47d7-a08e-c3be6da0ff1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='¿Cómo funcionan?'])[1]/preceding::h1[1]</value>
      <webElementGuid>0897cda9-84a8-484e-9db2-2e118592c084</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='¡COMPRA AHORA, DISFRUTA CUANDO QUIERAS!']/parent::*</value>
      <webElementGuid>7a193301-6427-4ea4-9c48-69dd487f0f47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>c3f144ce-3273-4128-88bf-a93006e8e5df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'CÓDIGOS CINEMARK: ¡COMPRA AHORA, DISFRUTA CUANDO QUIERAS!' or . = 'CÓDIGOS CINEMARK: ¡COMPRA AHORA, DISFRUTA CUANDO QUIERAS!')]</value>
      <webElementGuid>0a395740-137d-4db1-9265-bd8bf0540c3f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
