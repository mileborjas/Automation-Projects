<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Los ms vendidos</name>
   <tag></tag>
   <elementGuidId>bc8da651-e111-4965-8376-f1daa43734d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Usa'])[1]/following::h1[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.MuiTypography-root.MuiTypography-h1.mui-18c6jdt</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>91ca1a9e-d14d-486b-9b96-36addfa32ae8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiTypography-root MuiTypography-h1 mui-18c6jdt</value>
      <webElementGuid>95f42276-57e2-4a0c-b672-279f24af25c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Los más vendidos</value>
      <webElementGuid>1195575a-86fc-4b9a-ae79-63257f4ef60e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg mui-bjhooc&quot;]/div[@class=&quot;MuiBox-root mui-15i1vgz&quot;]/h1[@class=&quot;MuiTypography-root MuiTypography-h1 mui-18c6jdt&quot;]</value>
      <webElementGuid>86130be8-e8d6-4514-8725-45cceb795d3f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Usa'])[1]/following::h1[1]</value>
      <webElementGuid>9711b313-1a45-45d8-8a60-7df73a27bb1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recibe'])[1]/following::h1[1]</value>
      <webElementGuid>3718ed1e-3afe-43d9-b6dc-22ee69537f18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$14.000'])[1]/preceding::h1[1]</value>
      <webElementGuid>62792c66-dcb5-44f7-a30b-d2baffe73837</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$9.000'])[1]/preceding::h1[2]</value>
      <webElementGuid>df68044a-8221-4771-8534-fae1c551e055</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Los más vendidos']/parent::*</value>
      <webElementGuid>dc01605c-ea77-4a46-9e19-c9bba51583cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/h1</value>
      <webElementGuid>a7632487-8812-4175-aeb0-90c197e7f63f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Los más vendidos' or . = 'Los más vendidos')]</value>
      <webElementGuid>73b29552-4a1a-4e46-84b0-65c0a709d9e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
