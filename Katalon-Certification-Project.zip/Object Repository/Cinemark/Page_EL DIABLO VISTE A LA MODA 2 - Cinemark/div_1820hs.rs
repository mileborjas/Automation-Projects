<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_1820hs</name>
   <tag></tag>
   <elementGuidId>65293896-baaa-4ee5-a58f-13476f9d655a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Dirección: Av. José Pedro Alessandri 1166, Local 4033, Ñuñoa'])[1]/following::div[11]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiBox-root.mui-1gz41ir > div.MuiBox-root.mui-13wu688 > div.MuiBox-root.mui-19midw5</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4b13fd25-0697-4c5f-abea-dbaddf20a46e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root mui-19midw5</value>
      <webElementGuid>5e584f4c-0d45-48fb-8143-b1a0c45b0949</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>18:20hs</value>
      <webElementGuid>3e7615ce-93cd-4dac-b2be-85e2379a3856</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg mui-bjhooc&quot;]/section[@class=&quot;MuiBox-root mui-1rsx85y&quot;]/div[@class=&quot;MuiBox-root mui-0&quot;]/div[@class=&quot;MuiBox-root mui-pfbuym&quot;]/div[@class=&quot;MuiBox-root mui-190r4ix&quot;]/div[@class=&quot;MuiBox-root mui-0&quot;]/div[@class=&quot;MuiBox-root mui-1h0dmo8&quot;]/div[@class=&quot;MuiBox-root mui-0&quot;]/div[@class=&quot;MuiBox-root mui-0&quot;]/section[@class=&quot;MuiBox-root mui-1onlnyv&quot;]/div[@class=&quot;MuiBox-root mui-112byoi&quot;]/div[@class=&quot;MuiBox-root mui-1gz41ir&quot;]/div[@class=&quot;MuiBox-root mui-13wu688&quot;]/div[@class=&quot;MuiBox-root mui-19midw5&quot;]</value>
      <webElementGuid>d5d7e1e3-ed86-4a55-ad42-7373e26dffd5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dirección: Av. José Pedro Alessandri 1166, Local 4033, Ñuñoa'])[1]/following::div[11]</value>
      <webElementGuid>6ea3d9e7-0a30-4f40-8987-5e941fbbc24e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cinemark Portal Ñuñoa'])[4]/following::div[11]</value>
      <webElementGuid>993c688c-446d-46fd-8c07-180904ac347a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cines más cercanos'])[1]/preceding::div[2]</value>
      <webElementGuid>5900d43e-27ed-4eb2-8081-55a33b62e500</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Comprar entradas'])[1]/preceding::div[6]</value>
      <webElementGuid>dfbd48ee-2134-45a5-898f-2e9cd5cc6e07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div[2]/div[2]/div</value>
      <webElementGuid>7fa1f476-00a7-4026-8620-89c1ac8e8f8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '18:20hs' or . = '18:20hs')]</value>
      <webElementGuid>117d8875-4de2-47b7-9c84-3c001f9d4a31</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
