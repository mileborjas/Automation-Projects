<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_2hTEEL DIABLO VISTE A LA MODA 2TE2D  PALCO  PREMIER</name>
   <tag></tag>
   <elementGuidId>a1e3bc52-9cab-439b-8960-89ced283d8bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='MA14'])[2]/following::div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2a71ae3d-a42f-418c-a3d3-e919f5bff53d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiGrid-root MuiGrid-item MuiGrid-grid-md-3 mui-ova1cg</value>
      <webElementGuid>83d02a25-e28d-491b-b4d1-28ff82cc4431</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>2hTEEL DIABLO VISTE A LA MODA 2TE2D · PALCO · PREMIER</value>
      <webElementGuid>e76b6ec7-cfbe-484c-9e7d-abb35252feef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;MuiContainer-root MuiContainer-maxWidthLg mui-bjhooc&quot;]/div[@class=&quot;MuiBox-root mui-0&quot;]/section[@class=&quot;MuiBox-root mui-q0in0t&quot;]/div[@class=&quot;MuiBox-root mui-0&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-container MuiGrid-spacing-lg-6 mui-1dksdgg&quot;]/div[@class=&quot;MuiGrid-root MuiGrid-item MuiGrid-grid-md-3 mui-ova1cg&quot;]</value>
      <webElementGuid>660515f2-12bb-4190-aaac-d0f39d677427</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MA14'])[2]/following::div[4]</value>
      <webElementGuid>fc73d49a-de55-4ce3-8c7c-7db0cd2a8043</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BACKROOMS'])[1]/following::div[5]</value>
      <webElementGuid>e0131282-0d7d-425e-867d-96af96faae25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]</value>
      <webElementGuid>cad31a85-106a-4d3c-b52f-a9f8bbbda533</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '2hTEEL DIABLO VISTE A LA MODA 2TE2D · PALCO · PREMIER' or . = '2hTEEL DIABLO VISTE A LA MODA 2TE2D · PALCO · PREMIER')]</value>
      <webElementGuid>37128d54-0192-4fd7-b6c0-fd2f4b5e6546</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
