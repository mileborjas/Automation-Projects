<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Correo electrnico seguro, inteligente y fcil de usar</name>
   <tag></tag>
   <elementGuidId>e807ab8b-aea2-4d50-b764-f9eb12eb4a95</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='m2']/div/div/div/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>2fd48c53-4114-4efe-82d8-09b34660e5cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>Heading_heading heading Heading_size:h1</value>
      <webElementGuid>1df7541b-8701-49e0-b2d5-10170f08d984</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Correo electrónico seguro, inteligente y fácil de usar</value>
      <webElementGuid>c2666583-2526-46df-b325-85bb3b7b83d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;m2&quot;)/div[1]/div[@class=&quot;Grid_grid Template5050Hero_wrapper&quot;]/div[@class=&quot;Grid_column Template5050Hero_content Template5050Hero_fixedRightPadding&quot;]/div[@class=&quot;Template5050Hero_heading&quot;]/h1[@class=&quot;Heading_heading heading Heading_size:h1&quot;]</value>
      <webElementGuid>b248f92c-96a9-42f6-850a-5e520b8faed7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='m2']/div/div/div/div/h1</value>
      <webElementGuid>e2fe6e7f-8fbf-4e6e-8fd7-3beabea87c03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Para uso laboral o comercial'])[1]/following::h1[1]</value>
      <webElementGuid>e8f6b210-5872-4b99-a570-7e728ef6c354</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Para uso personal'])[1]/following::h1[1]</value>
      <webElementGuid>d84afedb-cb50-4393-bf7a-e222bd5fb5db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Crear una cuenta'])[2]/preceding::h1[1]</value>
      <webElementGuid>f30e7c35-846f-477a-a27b-0c5ff02da4bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Para uso personal'])[2]/preceding::h1[1]</value>
      <webElementGuid>5587c311-2753-42bd-b7ac-9c60443ae057</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Correo electrónico seguro, inteligente y fácil de usar']/parent::*</value>
      <webElementGuid>80e2f7a9-7e02-4134-b93c-0ba76cbfbdd5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>66e52aad-0971-4c59-a2d2-5296a8e37518</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Correo electrónico seguro, inteligente y fácil de usar' or . = 'Correo electrónico seguro, inteligente y fácil de usar')]</value>
      <webElementGuid>8b1f897e-e302-4f1c-959b-2f1c7e03a615</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
