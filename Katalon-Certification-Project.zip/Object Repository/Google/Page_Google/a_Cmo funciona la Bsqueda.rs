<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Cmo funciona la Bsqueda</name>
   <tag></tag>
   <elementGuidId>615b375b-f4bd-4203-982a-9724703234aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Cómo funciona la Búsqueda')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>88a54fd9-f02c-4182-8b69-e2086bd79342</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>pHiOh</value>
      <webElementGuid>e8694f48-eda7-44f2-9e8e-038f03cdb797</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://google.com/search/howsearchworks/?fg=1</value>
      <webElementGuid>ffe3cd52-e725-49b5-b3da-dcbf635fe90f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Cómo funciona la Búsqueda </value>
      <webElementGuid>9fb02312-4e99-4d19-af46-292db1aa9bb2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;L3eUgb&quot;]/div[@class=&quot;o3j99&quot;]/div[@class=&quot;c93Gbe&quot;]/div[@class=&quot;KxwPGc SSwjIe&quot;]/div[@class=&quot;KxwPGc AghGtd&quot;]/a[@class=&quot;pHiOh&quot;]</value>
      <webElementGuid>afc5b086-fb1e-4e62-95b7-c2b45d4f57e4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Cómo funciona la Búsqueda')]</value>
      <webElementGuid>30b55c35-b6a1-49a6-950d-34e3a2e8856a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Negocios'])[1]/following::a[1]</value>
      <webElementGuid>21d1b121-57b6-4ff0-bd07-a42d81349f62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publicidad'])[1]/following::a[2]</value>
      <webElementGuid>946517ac-a86a-4be5-b96b-b4426a05e4ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Privacidad'])[1]/preceding::a[1]</value>
      <webElementGuid>34d96b8e-361d-4a82-bdf9-ef6a0238cf14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Condiciones'])[1]/preceding::a[2]</value>
      <webElementGuid>6873623f-145e-4a64-8414-d92f551084e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Cómo funciona la Búsqueda']/parent::*</value>
      <webElementGuid>907a6578-f935-4631-bb8b-50eb75270cf5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://google.com/search/howsearchworks/?fg=1')]</value>
      <webElementGuid>151bf6f5-c2f6-44eb-85e0-7a33f95286f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[4]</value>
      <webElementGuid>f4123197-b030-4b45-bc46-27804c605da8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://google.com/search/howsearchworks/?fg=1' and (text() = ' Cómo funciona la Búsqueda ' or . = ' Cómo funciona la Búsqueda ')]</value>
      <webElementGuid>07581ee8-6c97-4bd0-8d23-a6f4c8a25562</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
