<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Modo IA</name>
   <tag></tag>
   <elementGuidId>e4c22c3c-d67d-4a54-bdfa-9d48443a9593</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.lTxWLe</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Crear imágenes'])[1]/following::span[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9185b12a-f701-42e7-be76-9fd59c497768</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>lTxWLe</value>
      <webElementGuid>7b071a80-5a4b-41d1-a6d6-67224b9d82b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Modo IA</value>
      <webElementGuid>902ef199-7d6f-475d-a456-70e09a98d017</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;L3eUgb&quot;]/div[@class=&quot;o3j99 ikrT4e KEY6ib&quot;]/form[1]/div[1]/div[@class=&quot;A8SBwf&quot;]/div[@class=&quot;RNNXgb&quot;]/div[@class=&quot;SDkEP&quot;]/div[@class=&quot;fM33ce dRYYxd&quot;]/button[@class=&quot;plR5qb Y5MKCd&quot;]/div[@class=&quot;u4Uk3c&quot;]/span[@class=&quot;lTxWLe&quot;]</value>
      <webElementGuid>77bc116c-0cdb-4bd2-9576-a2159a456834</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Crear imágenes'])[1]/following::span[4]</value>
      <webElementGuid>01437b34-2bed-4468-8d5f-90aab683b3df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subir archivo'])[1]/following::span[7]</value>
      <webElementGuid>53f554c3-80f5-4bd8-aa4f-f61f5d01eb69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Crear'])[1]/preceding::span[5]</value>
      <webElementGuid>ee3cea27-3ae3-4247-b279-c70e0b31deb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elige sobre qué enviarás comentarios'])[1]/preceding::span[8]</value>
      <webElementGuid>8bb7c458-fd27-45d1-9a7f-ccf515033a8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Modo IA']/parent::*</value>
      <webElementGuid>e1fa7dbd-1001-4fa2-a731-f924f6afb097</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/span[2]</value>
      <webElementGuid>214b2463-6a60-427e-b032-218ee345a07e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Modo IA' or . = 'Modo IA')]</value>
      <webElementGuid>3f9745d8-6db6-4dea-a4b8-94a3a569a21e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
