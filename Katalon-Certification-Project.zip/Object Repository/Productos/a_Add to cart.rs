<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Add to cart</name>
   <tag></tag>
   <elementGuidId>47fe4e02-81e3-4897-9472-8405f2eaabab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Add to cart')])[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.overlay-content > a.btn.btn-default.add-to-cart</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e196b9ac-61c5-4be9-a27e-bc3e325f7067</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-product-id</name>
      <type>Main</type>
      <value>1</value>
      <webElementGuid>96c6c83d-0cc5-44d1-959a-7601a7c5fc07</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default add-to-cart</value>
      <webElementGuid>b1bef926-91d3-4d80-b7a6-8ba402ec0922</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add to cart</value>
      <webElementGuid>de4f4a30-4f15-429e-96e2-63c95b291ba5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[2]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 padding-right&quot;]/div[@class=&quot;features_items&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;product-image-wrapper&quot;]/div[@class=&quot;single-products&quot;]/div[@class=&quot;product-overlay&quot;]/div[@class=&quot;overlay-content&quot;]/a[@class=&quot;btn btn-default add-to-cart&quot;]</value>
      <webElementGuid>9668a492-0cb9-462c-82e4-db2a960d1c46</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Add to cart')])[2]</value>
      <webElementGuid>fe2ecf3c-4b67-4dd3-af72-816b61c563f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rs. 500'])[2]/following::a[1]</value>
      <webElementGuid>abae2f19-a5e4-4f62-abfb-599067f7cf1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to cart'])[1]/following::a[1]</value>
      <webElementGuid>226d365b-90a3-45cf-becb-c7604848cf33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View Product'])[1]/preceding::a[1]</value>
      <webElementGuid>be09bb1a-5755-45d6-852f-1eca74db0bf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rs. 400'])[1]/preceding::a[2]</value>
      <webElementGuid>fdc676ec-dd1d-44ff-b9f4-53d9d73171cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a</value>
      <webElementGuid>c7050c11-78bf-4c68-bb88-ae192159d70e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'Add to cart' or . = 'Add to cart')]</value>
      <webElementGuid>23399fa2-2c49-4664-bcb2-b11a6f85399b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
