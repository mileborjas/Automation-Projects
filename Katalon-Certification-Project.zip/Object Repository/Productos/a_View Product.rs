<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_View Product</name>
   <tag></tag>
   <elementGuidId>9fdd7a0e-d0cf-4bce-8af7-ba3efdf67a2b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'View Product')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-pills.nav-justified > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3f88ab81-3cd0-417d-a581-261dc640daf3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/product_details/1</value>
      <webElementGuid>05a0968c-5227-401f-8219-ba634ac2bc81</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>View Product</value>
      <webElementGuid>a976a5c5-fa3b-4a6c-a14e-cef7e7903869</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[2]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 padding-right&quot;]/div[@class=&quot;features_items&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;product-image-wrapper&quot;]/div[@class=&quot;choose&quot;]/ul[@class=&quot;nav nav-pills nav-justified&quot;]/li[1]/a[1]</value>
      <webElementGuid>bb01fc80-51a5-4366-9a6f-3782e183decd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'View Product')]</value>
      <webElementGuid>26d41005-e3e1-45a7-8166-bf096bbb1fc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to cart'])[2]/following::a[1]</value>
      <webElementGuid>5f2d155b-ae97-4383-965d-9a223477b2d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rs. 500'])[2]/following::a[2]</value>
      <webElementGuid>443c85b2-7da1-4ae5-9def-3625aa6b55dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rs. 400'])[1]/preceding::a[1]</value>
      <webElementGuid>4f5d7327-5ef4-4e68-b43a-787e185b6091</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to cart'])[3]/preceding::a[1]</value>
      <webElementGuid>681f6d96-709b-4ed6-acc2-c8a4b698b31b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='View Product']/parent::*</value>
      <webElementGuid>e7dfe041-6e13-4a61-b54a-28ed39a40547</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/product_details/1')]</value>
      <webElementGuid>013a7616-e33a-42a5-9c9d-3944739c7c25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li/a</value>
      <webElementGuid>d3a76b47-d95a-4bd6-ac63-d363e92415d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/product_details/1' and (text() = 'View Product' or . = 'View Product')]</value>
      <webElementGuid>8efe6516-4f00-416b-a1a9-e65a611eb231</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
