<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Banner del Home</name>
   <tag></tag>
   <elementGuidId>24a2d4a2-7380-4df6-bc4d-8e9f7afd17d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='slider']/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-sm-12</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>25b5f802-0fa9-4b78-936a-59e81f5705b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-12</value>
      <webElementGuid>fd391416-3d5b-45c5-ba0b-c9daacd3da89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
					
						
							
							
							
						
						
						
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
						
						
						
							
						
						
							
						
					
					
				</value>
      <webElementGuid>70623d23-31bb-4074-97e2-e73389a20554</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;slider&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-12&quot;]</value>
      <webElementGuid>8c23f75b-8193-41f6-bd72-a2b648c712db</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='slider']/div/div/div</value>
      <webElementGuid>3354ecc3-bffe-4c2c-b153-db2455670a79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact us'])[1]/following::div[3]</value>
      <webElementGuid>718d1d9d-6c18-464f-8914-498e8433510b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Video Tutorials'])[1]/following::div[3]</value>
      <webElementGuid>5f3c7dae-12d4-4787-9146-b2c36e196694</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div/div</value>
      <webElementGuid>2559ed03-5879-40d1-b4cd-12ee2f44f654</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
					
						
							
							
							
						
						
						
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
						
						
						
							
						
						
							
						
					
					
				' or . = '
					
						
							
							
							
						
						
						
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
								
									AutomationExercise
									Full-Fledged practice website for Automation Engineers
									All QA engineers can use this website for automation practice and API testing either they are at beginner or advance level. This is for everybody to help them brush up their automation skills.
									Test Cases
									APIs list for practice
								
								
									
								
							
							
						
						
						
							
						
						
							
						
					
					
				')]</value>
      <webElementGuid>d7065c80-4c7a-473c-9ce0-d4bdf939cb1b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
