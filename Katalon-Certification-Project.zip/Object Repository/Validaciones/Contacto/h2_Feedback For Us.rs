<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Feedback For Us</name>
   <tag></tag>
   <elementGuidId>340a6f5c-0d86-4f44-9d80-4140809b2cfc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='contact-page']/div[2]/div[2]/div/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.contact-info > h2.title.text-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>6407cecb-b0b9-4fdb-a905-43e03bf17607</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-center</value>
      <webElementGuid>5d1b150c-c4e1-4961-b36f-4243ceab5ef6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Feedback For Us</value>
      <webElementGuid>29f401ae-9aee-441e-a030-1bcf78b29413</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;contact-page&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;contact-info&quot;]/h2[@class=&quot;title text-center&quot;]</value>
      <webElementGuid>d58ca0ad-3205-47d6-9d33-b3e4a43c11c2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='contact-page']/div[2]/div[2]/div/h2</value>
      <webElementGuid>4db8011c-646c-4906-b95e-92a36284b52d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get In Touch'])[1]/following::h2[1]</value>
      <webElementGuid>b9c34854-6735-4edb-bf36-7b9a4b77c5fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note:'])[1]/following::h2[2]</value>
      <webElementGuid>c3b28956-a504-43c0-8011-17fdf98854c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='feedback@automationexercise.com'])[1]/preceding::h2[1]</value>
      <webElementGuid>71d6338e-84ea-499e-875f-49293bbf48b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='You have been successfully subscribed!'])[1]/preceding::h2[1]</value>
      <webElementGuid>56794722-c138-4e5d-ab5b-bebee9ea8169</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Feedback For Us']/parent::*</value>
      <webElementGuid>3723407d-9e61-4cd1-8408-61cd6b242405</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h2</value>
      <webElementGuid>b675bd4c-48d3-4740-969a-ebaac1e6e5fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Feedback For Us' or . = 'Feedback For Us')]</value>
      <webElementGuid>0c43b666-1c99-482e-87ed-6cbb67ed806b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
