<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Get In Touch</name>
   <tag></tag>
   <elementGuidId>34ccc1d6-9fd7-47fc-a367-2d51a0337f7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='contact-page']/div[2]/div/div/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.contact-form > h2.title.text-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>9ff41936-732b-4ac6-bb3e-e56fde985699</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-center</value>
      <webElementGuid>6e3c889a-fb5e-4974-9234-d52a679e60d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Get In Touch</value>
      <webElementGuid>93f6b4eb-2185-46fd-a928-9b02b3da2b10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;contact-page&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-8&quot;]/div[@class=&quot;contact-form&quot;]/h2[@class=&quot;title text-center&quot;]</value>
      <webElementGuid>ffc0d024-71bc-457c-a903-aab25bcd973e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='contact-page']/div[2]/div/div/h2</value>
      <webElementGuid>5ecb626f-733d-4ee6-9c0d-fa926ccbde29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note:'])[1]/following::h2[1]</value>
      <webElementGuid>e6bb7702-617d-415d-a2f4-c57b96d59939</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback For Us'])[1]/preceding::h2[1]</value>
      <webElementGuid>bb3716d7-3b1d-4c27-88a6-affd22db8966</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='feedback@automationexercise.com'])[1]/preceding::h2[2]</value>
      <webElementGuid>be0b069f-136d-473b-a310-e91cd6e39848</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Get In Touch']/parent::*</value>
      <webElementGuid>ab122137-eb9b-42f1-9c43-0d7cc957bd92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/h2</value>
      <webElementGuid>dfa4367b-5ac2-4de7-80c5-753fc8e81b5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Get In Touch' or . = 'Get In Touch')]</value>
      <webElementGuid>a8454dff-da0d-4100-b314-91916889f5bb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
