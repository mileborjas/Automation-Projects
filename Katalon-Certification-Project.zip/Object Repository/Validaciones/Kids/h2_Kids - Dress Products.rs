<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Kids - Dress Products</name>
   <tag></tag>
   <elementGuidId>879f2fce-98cc-4e4d-b2d0-38898dd356ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.title.text-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>b7f10083-bbf0-47be-b4de-ca03314dd034</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-center</value>
      <webElementGuid>459d0a19-d454-43e9-b633-6fe4d2ef7271</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kids - Dress Products</value>
      <webElementGuid>5daf9b14-1dea-4c4d-86ed-d489d84b2030</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 padding-right&quot;]/div[@class=&quot;features_items&quot;]/h2[@class=&quot;title text-center&quot;]</value>
      <webElementGuid>447b191e-5c2b-42d8-b03d-de8db278e9a4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      <webElementGuid>5016760e-0d6f-4027-8408-40df3fa243b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=''])[1]/preceding::h2[1]</value>
      <webElementGuid>becd6a20-ee09-4b1e-ab76-b3f6da6a203a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Added!'])[1]/preceding::h2[1]</value>
      <webElementGuid>d8ddbb26-85f4-4e6b-9f81-54e19fa4b4b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kids - Dress Products']/parent::*</value>
      <webElementGuid>cc9ef39e-eb78-4196-9cb0-7c04858498ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h2</value>
      <webElementGuid>460965a4-1249-48eb-9998-f768119348d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Kids - Dress Products' or . = 'Kids - Dress Products')]</value>
      <webElementGuid>66911b1b-65b6-4ff7-8916-1ab726f99987</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
