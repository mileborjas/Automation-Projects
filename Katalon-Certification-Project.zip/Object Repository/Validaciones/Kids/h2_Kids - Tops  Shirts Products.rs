<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Kids - Tops  Shirts Products</name>
   <tag></tag>
   <elementGuidId>810b540d-7da1-4476-81df-915e4deeb099</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.title.text-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>5bf37bb5-87e3-48d4-8bb1-89986397a148</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-center</value>
      <webElementGuid>a053d19d-fe5d-46be-a12c-5bf3ca0ec9a1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kids - Tops &amp; Shirts Products</value>
      <webElementGuid>775e6174-bbc6-4067-8a4c-f698f683896a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 padding-right&quot;]/div[@class=&quot;features_items&quot;]/h2[@class=&quot;title text-center&quot;]</value>
      <webElementGuid>7f9dd939-4c21-49b9-87c7-81a2a7b7adc9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      <webElementGuid>19f2d413-ca8c-4e98-99ba-17b169958ced</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=''])[1]/preceding::h2[1]</value>
      <webElementGuid>bf4164f6-ccfe-48c7-bc2d-5d702c84855b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Added!'])[1]/preceding::h2[1]</value>
      <webElementGuid>da1ded63-1bcf-4175-a791-89382991b5ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kids - Tops &amp; Shirts Products']/parent::*</value>
      <webElementGuid>4772e154-9d9c-4a63-9770-27bbab0f03e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h2</value>
      <webElementGuid>324403a6-cb78-4ef5-969d-ae1c929a43e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Kids - Tops &amp; Shirts Products' or . = 'Kids - Tops &amp; Shirts Products')]</value>
      <webElementGuid>a332e54f-5598-4480-a4c8-8448c49dbc26</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
