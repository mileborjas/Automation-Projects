<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_All Products</name>
   <tag></tag>
   <elementGuidId>ab39c7fa-12c0-49ed-b868-34b5a4254701</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.title.text-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>44008544-68cc-4b59-b296-38dbc56cb692</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-center</value>
      <webElementGuid>57ad544a-fec6-4272-a6c5-06c38a081314</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>All Products</value>
      <webElementGuid>f4e0d457-7393-45e7-9743-0b2ca9f7f571</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[2]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 padding-right&quot;]/div[@class=&quot;features_items&quot;]/h2[@class=&quot;title text-center&quot;]</value>
      <webElementGuid>082933aa-9335-4f6a-8edf-25630c3e8ca4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      <webElementGuid>9d1d8a9f-9a2c-4777-8b06-1610bc88b805</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=''])[1]/preceding::h2[1]</value>
      <webElementGuid>65149c7f-6256-4802-a90c-a03baea2f27a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Added!'])[1]/preceding::h2[1]</value>
      <webElementGuid>4f8fdbd0-9035-4626-a26f-e0e241872d0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='All Products']/parent::*</value>
      <webElementGuid>f6e5d388-ab5a-4f13-8c44-5470f9200f5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h2</value>
      <webElementGuid>84f19ac4-e672-4427-973e-3001d14021e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'All Products' or . = 'All Products')]</value>
      <webElementGuid>d3626817-c346-4417-a157-7d11a58c70ea</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
