<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Women - Dress Products</name>
   <tag></tag>
   <elementGuidId>ee0b8329-d081-4b37-9ae0-86a50169ebf1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.title.text-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>f0e3facc-64a3-4954-9779-567e92612846</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-center</value>
      <webElementGuid>a2ba526d-d4a9-4f93-940b-609ae24aa192</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Women - Dress Products</value>
      <webElementGuid>7b09b657-a49b-4e9b-b67f-62dfccb95380</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 padding-right&quot;]/div[@class=&quot;features_items&quot;]/h2[@class=&quot;title text-center&quot;]</value>
      <webElementGuid>321706ae-f0a4-42b5-9190-08a8eb19e3a4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(5)'])[3]/following::h2[1]</value>
      <webElementGuid>dc6b55d3-4a17-45c4-b14d-172107d5f733</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=''])[1]/preceding::h2[1]</value>
      <webElementGuid>d7b84fb6-f271-4424-ab1f-1b27f1198e10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Added!'])[1]/preceding::h2[1]</value>
      <webElementGuid>aec57285-455b-4460-af05-e6f95e098b04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Women - Dress Products']/parent::*</value>
      <webElementGuid>e27f9d43-7eb9-4f62-b7fc-fa598ababcd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h2</value>
      <webElementGuid>14de57e1-2d27-4c9a-b9cb-cc272f43a705</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Women - Dress Products' or . = 'Women - Dress Products')]</value>
      <webElementGuid>46a1be95-585d-4e32-993f-e699947d278d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
