<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Cambios recientes</name>
   <tag></tag>
   <elementGuidId>7da5ce00-554a-4820-8fc6-04a12a5c920d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='n-recentchanges']/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Lista de cambios recientes en la wiki [alt-r]&quot;] > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f1e8303f-dfc2-49b7-b674-2bba9c27a858</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Cambios recientes</value>
      <webElementGuid>4c48e591-4f14-4e62-9043-ffe3039e3ea9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;n-recentchanges&quot;)/a[1]/span[1]</value>
      <webElementGuid>9063270d-1e22-4358-a8d8-db6f33093479</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='n-recentchanges']/a/span</value>
      <webElementGuid>aa8dd8fe-8a8b-40f6-a647-b676d554342f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Actualidad'])[1]/following::span[1]</value>
      <webElementGuid>bf6b8f70-9e46-4946-b14a-9c83625f81ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Portal de la comunidad'])[1]/following::span[2]</value>
      <webElementGuid>e1923845-dc5e-4639-ae63-d7ab0cdbe3b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Páginas nuevas'])[1]/preceding::span[1]</value>
      <webElementGuid>2f7eecc5-2ffe-4b48-9d57-b143242f38f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Página aleatoria'])[1]/preceding::span[2]</value>
      <webElementGuid>69196e66-c11f-40e0-b038-558150bb4779</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Cambios recientes']/parent::*</value>
      <webElementGuid>cdfdfeb6-3ee4-4516-bd08-03325e28398b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/a/span</value>
      <webElementGuid>02e2656b-9570-4ddc-9444-8c243328db64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Cambios recientes' or . = 'Cambios recientes')]</value>
      <webElementGuid>041c6937-5c14-4036-bae6-cdc5dcd6652c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
