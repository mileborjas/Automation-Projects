<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Pgina aleatoria</name>
   <tag></tag>
   <elementGuidId>fde38c5e-a1dc-4620-8ec8-d1034c906461</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='n-randompage']/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Cargar una página al azar [alt-x]&quot;] > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>95f6aafe-772b-4024-84ea-301e6d9f891f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Página aleatoria</value>
      <webElementGuid>c041abfa-4dca-4de2-bd12-47d298e8f37d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;n-randompage&quot;)/a[1]/span[1]</value>
      <webElementGuid>a1166f57-5230-45b9-94c8-1dc1309fa8d7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='n-randompage']/a/span</value>
      <webElementGuid>88a0fbb4-97e0-497a-9c76-db0abae520d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Páginas nuevas'])[1]/following::span[1]</value>
      <webElementGuid>1cd22858-9769-4a7d-874d-238a1ac9c1ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cambios recientes'])[1]/following::span[2]</value>
      <webElementGuid>d616304c-af0b-4d69-a677-ddfe350f5083</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ayuda'])[1]/preceding::span[1]</value>
      <webElementGuid>ce2de7ed-7607-44f9-bdeb-7741e7d6b339</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notificar un error'])[1]/preceding::span[2]</value>
      <webElementGuid>b2d84d99-1719-4fbf-9b02-c9eb47067f81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Página aleatoria']/parent::*</value>
      <webElementGuid>b5d2a06f-7dbb-4477-92af-8bef108f2a71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/a/span</value>
      <webElementGuid>c4e4eea3-e664-4913-bcb2-44465902b5dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Página aleatoria' or . = 'Página aleatoria')]</value>
      <webElementGuid>c4098fb4-a526-4ef3-a9be-a33bf504bdc8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
