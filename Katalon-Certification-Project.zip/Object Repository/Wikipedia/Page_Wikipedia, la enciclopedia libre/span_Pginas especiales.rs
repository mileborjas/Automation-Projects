<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Pginas especiales</name>
   <tag></tag>
   <elementGuidId>c0d0fcec-29d5-440e-aec5-c97a3c826614</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='n-specialpages']/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Lista de todas las páginas especiales [alt-q]&quot;] > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>92e0c5b3-dfaf-4a6b-9f3c-8a058c84c137</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Páginas especiales</value>
      <webElementGuid>48ad4eca-aabe-48d2-9e54-fafa8486e5b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;n-specialpages&quot;)/a[1]/span[1]</value>
      <webElementGuid>97fa0016-71df-4939-8c4d-cba903cec5eb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='n-specialpages']/a/span</value>
      <webElementGuid>9b916846-2c34-4fe1-98a5-c251c9f8eb95</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notificar un error'])[1]/following::span[1]</value>
      <webElementGuid>12638f2b-51eb-4fda-9566-289d6b08f24f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ayuda'])[1]/following::span[2]</value>
      <webElementGuid>a0e6f96c-6586-4059-9ed6-40a6941216e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buscar'])[1]/preceding::span[3]</value>
      <webElementGuid>0915b084-d59d-4b82-b5ab-b408acde46e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Buscar'])[2]/preceding::span[5]</value>
      <webElementGuid>02888961-16c7-495c-95be-aedcc637317d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Páginas especiales']/parent::*</value>
      <webElementGuid>bf3059af-c349-4e65-b41c-b9a5b91961b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[9]/a/span</value>
      <webElementGuid>539e2d03-7b71-4545-8afe-2a53dc5e7233</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Páginas especiales' or . = 'Páginas especiales')]</value>
      <webElementGuid>40d35ec4-f8d5-4ca6-b1c6-7a6d7d28347d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
