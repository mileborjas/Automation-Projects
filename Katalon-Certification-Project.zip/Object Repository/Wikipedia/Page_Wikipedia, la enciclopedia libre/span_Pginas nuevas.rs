<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Pginas nuevas</name>
   <tag></tag>
   <elementGuidId>62180a31-c9ff-40f0-8b73-92383b72cc71</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='n-newpages']/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#n-newpages > a > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e0586ec4-05bb-4dc5-956f-e8bf975fcd00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Páginas nuevas</value>
      <webElementGuid>c1b61d85-de4a-4ebb-96af-87e1b6753478</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;n-newpages&quot;)/a[1]/span[1]</value>
      <webElementGuid>b4517883-d018-43cb-84e0-39e5871556b6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='n-newpages']/a/span</value>
      <webElementGuid>95a801b6-26b9-4351-9e32-c87662e6ed0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cambios recientes'])[1]/following::span[1]</value>
      <webElementGuid>a2e5b170-ec58-444a-a66e-5d50ae5b7dc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Actualidad'])[1]/following::span[2]</value>
      <webElementGuid>565129da-6480-4387-a029-3ef3544a9c9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Página aleatoria'])[1]/preceding::span[1]</value>
      <webElementGuid>1e649818-6919-4e30-9735-695ce61504f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ayuda'])[1]/preceding::span[2]</value>
      <webElementGuid>bc156d81-bdae-4ca1-8a24-b52ae3357714</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Páginas nuevas']/parent::*</value>
      <webElementGuid>cb5d5593-b7f2-4f50-9df7-27e21ae751df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a/span</value>
      <webElementGuid>b759f0b1-f736-4af5-b2da-f7edf365bb5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Páginas nuevas' or . = 'Páginas nuevas')]</value>
      <webElementGuid>4fcdfb37-d3cd-4fdc-aa47-b9db3c8e5e9a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
